package com.example.dropdown1;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] cities = {"Mumbai", "Delhi", "Banglore", "Calicut", "Chennai", "Dalhosie", "Daman", "Diu"};
        Button b1;
        final Spinner spino = (Spinner) findViewById(R.id.spinner2);
        spino.setOnItemSelectedListener(this);

        // Create the instance of ArrayAdapter
        // having the list of courses
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, cities);
        // set simple layout resource file
        // for each item of spinner
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the
        // Spinner which binds data to spinner
        spino.setAdapter(ad);
        b1=(Button)findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent n1 = new Intent(MainActivity.this, MainActivitydisplay.class);
                n1.putExtra("data",String.valueOf(spino.getSelectedItem()));
                startActivity(n1);

            }
        });
    }

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //on selecting spinner item
                String item=parent.getItemAtPosition(position).toString();
                 //showing selected spinner item
               Toast.makeText(parent.getContext(),"selected:" +item, Toast.LENGTH_LONG).show();
                //String item=spino.getSelectedItem().toString();
                //showing selected spinner item
                Toast.makeText(this,item,Toast.LENGTH_LONG).show();
            }


            // Performing action when ItemSelected
            // from spinner, Overriding onItemSelected method


            @Override
              public void onNothingSelected(AdapterView<?> arg0) {
                // Auto-generated method stub
            }
}




