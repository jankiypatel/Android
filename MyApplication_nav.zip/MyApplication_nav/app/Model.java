package com.example.myapplication_nav;

public class Model {
    String uid;
    String country;


    public Model(String uid) {
        this.uid = uid;
        this.country = cname;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUname() {
        return cname;
    }

    public void setUname(String cname) {
        this.cname = cname;
    }


