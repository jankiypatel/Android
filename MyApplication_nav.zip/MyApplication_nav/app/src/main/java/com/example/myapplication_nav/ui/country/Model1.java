package com.example.myapplication_nav.ui.country;


    public class Model1 {
        String uid;
        String country;


        public Model1(String uid) {
            this.uid = uid;
            this.country = country;
        }



        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getUname() {
            return country;
        }

        public void setUname(String cname) {
            this.country = country;
        }


    }
