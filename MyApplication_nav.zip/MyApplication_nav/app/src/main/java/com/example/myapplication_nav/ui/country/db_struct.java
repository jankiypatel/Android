package com.example.myapplication_nav.ui.country;

public class db_struct {
    public static final String DB_NAME = "hamburger";
    public static final String DB_TABLE = "countries";
    public static final int DB_VERSION = 1;
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "country";

}
