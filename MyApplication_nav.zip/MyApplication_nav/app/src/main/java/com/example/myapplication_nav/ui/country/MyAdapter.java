package com.example.myapplication_nav.ui.country;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication_nav.R;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    ArrayList<Model1> dataholder;

    public MyAdapter(ArrayList<Model1> dataholder) {
        this.dataholder = dataholder;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        // create a new view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_country__lists, parent, false);
        return new MyViewHolder(v);

    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element++++
        holder.id.setText(dataholder.get(position).getUid());
        holder.uname.setText(dataholder.get(position).getUname());

    }
    class MyViewHolder extends RecyclerView.ViewHolder {

        // each data item is just a string in this case
      //  public TextView textView;
        CardView cardView;
        TextView id,uname;
        public MyViewHolder(@NonNull View v) {
            super(v);
           // cardView = (CardView)v.findViewById(R.id.cview);
           id=(TextView)v.findViewById(R.id.c1);
            uname=(TextView)v.findViewById(R.id.c2);
        }
    }


    @Override
    public int getItemCount() {
        return dataholder.size();
    }
}

