package com.example.myapplication_nav;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.myapplication_nav.ui.main.StateFragment;

public class State extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.state_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, StateFragment.newInstance())
                    .commitNow();
        }
    }
}