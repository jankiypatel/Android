package com.example.myapplication_nav.ui.main;

import androidx.lifecycle.ViewModel;

public class CitiesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}