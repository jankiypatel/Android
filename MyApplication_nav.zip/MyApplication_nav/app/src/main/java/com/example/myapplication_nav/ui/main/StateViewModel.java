package com.example.myapplication_nav.ui.main;

import androidx.lifecycle.ViewModel;

public class StateViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}