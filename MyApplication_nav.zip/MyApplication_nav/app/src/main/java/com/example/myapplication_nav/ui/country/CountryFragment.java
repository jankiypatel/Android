package com.example.myapplication_nav.ui.country;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProviders;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import com.example.myapplication_nav.R;
import com.example.myapplication_nav.Recycle;
import com.example.myapplication_nav.RegDBHelper;
import com.example.myapplication_nav.db_struct;

public class CountryFragment extends Fragment {
    Button insert,selectall;
    private CountryViewModel mViewModel;
    private EditText ctry;
    public static CountryFragment newInstance() {
        return new CountryFragment();
    }
    @SuppressLint("WrongViewCast")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.country_fragment,container, false);
        ctry = (EditText) root.findViewById(R.id.editText1);
        AlertDialog alert= null;
        final RegDBHelper dbHelper = new RegDBHelper(getActivity());
        final AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        insert = (Button) root.findViewById(R.id.button);
        selectall=(Button) root.findViewById(R.id.button2);
        insert.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    if (ctry.getText().toString().equalsIgnoreCase("")) {
                        builder.setTitle("Error");
                        builder.setMessage("Please enter country");
                        builder.show();
                    }
                    else {
                        boolean isInserted = dbHelper.insert(db_struct.DB_TABLE,
                                new String[]{db_struct.COLUMN_NAME},
                                new String[]{ctry.getText().toString()});

                        if (isInserted == true) {
                            builder.setTitle("Success");
                            builder.setMessage("countries inserted successfully!!");
                            builder.show();
                           Intent intent = new Intent(getActivity().getApplication(), Recycle.class);
                           startActivity(intent);
                        } else {
                            builder.setTitle("Error");
                            builder.setMessage("Username already exists");
                            builder.show();
                        }
                    }
                }
            });


        builder.create().show();
        return root;
        }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(CountryViewModel.class);
        // TODO: Use the ViewModel
    }
}


