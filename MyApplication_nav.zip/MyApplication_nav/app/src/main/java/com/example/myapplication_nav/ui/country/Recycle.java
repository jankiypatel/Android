package com.example.myapplication_nav.ui.country;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication_nav.R;

import java.util.ArrayList;

public class Recycle extends AppCompatActivity {
    RecyclerView recyclerView;
    CardView cardView;
    ArrayList<Model1> dataholder;
    private RecyclerView.Adapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // use a linear layout manager
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // specify an adapter (see also next example)
        //  mAdapter = new MyAdapter(myDataset);
        // recyclerView.setAdapter(mAdapter);
        Cursor cursor = new RegDBHelper(this).selectalldata();
        dataholder=new ArrayList<>();
        String data = "";
        while (cursor.moveToNext()) {
            Model1 obj;
            obj = new Model1("\n\n\n\n\n\n"+"userid: " + cursor.getString(0) + '\n' +
                    "countryname: " + cursor.getString(1) );
            dataholder.add(obj);
        }
        mAdapter = new MyAdapter(dataholder);
        recyclerView.setAdapter(mAdapter);
    }
}