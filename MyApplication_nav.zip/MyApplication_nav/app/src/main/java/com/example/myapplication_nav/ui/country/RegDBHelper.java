package com.example.myapplication_nav.ui.country;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public final class RegDBHelper extends SQLiteOpenHelper{

    public RegDBHelper(Context context) {
        super(context,db_struct.DB_NAME,null,1);
    }



    @Override

        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL("Create table if not exists "+ db_struct.DB_TABLE+" (_id INTEGER PRIMARY KEY AUTOINCREMENT,"+ db_struct.COLUMN_NAME+" text NOT NULL unique)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("drop table if exists "+ db_struct.DB_TABLE);
            onCreate(sqLiteDatabase);
        }

        public boolean insert(String table_name, String[] parameterName, String[] parameterValue){
            ContentValues cv=new ContentValues();

            for(int i=0;i<parameterName.length;i++){
                cv.put(parameterName[i], parameterValue[i]);
            }

            SQLiteDatabase db=this.getWritableDatabase();
            long result = db.insert(table_name,null,cv);
            if(result == -1) return false;
            else return true;
        }

        public boolean insertdata(String ctry)
        {
            SQLiteDatabase db=this.getWritableDatabase();
            ContentValues cv=new ContentValues();
            cv.put(db_struct.COLUMN_NAME, ctry);
                       long result = db.insert(db_struct.DB_TABLE,null,cv);
            if(result == -1) return false;
            else return true;
        }
    public Object getData(String cname) {
        Cursor c;
        try (SQLiteDatabase db = this.getWritableDatabase()) {
            String query=" select count(*) from "+ db_struct.DB_TABLE+" where country = '"+cname+"' ";
            Cursor cursor = db.rawQuery(query, null);
            cursor.moveToFirst();
            String count = cursor.getString(cursor.getColumnIndex(cursor.getColumnName(0)));
            return count;

        }
        }

    public Cursor selectalldata() {
        Cursor c2;
        SQLiteDatabase db = this.getWritableDatabase();
            c2 = db.rawQuery("SELECT * FROM "+ db_struct.DB_TABLE, null);
            return c2;
        //   Cursor c1 = dbHelper.selectalldata();

        }
    }



