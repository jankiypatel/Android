package com.example.myapplication_nav.ui.country;

import androidx.lifecycle.ViewModel;

public class CountryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}