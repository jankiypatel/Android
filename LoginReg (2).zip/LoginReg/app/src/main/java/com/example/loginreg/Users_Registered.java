package com.example.loginreg;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import android.os.Bundle;
import java.util.ArrayList;

public class Users_Registered extends AppCompatActivity {
    RecyclerView recyclerView;
    CardView cardView;
    ArrayList<Model> dataholder;
    private RecyclerView.Adapter mAdapter;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users__registered);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // use a linear layout manager

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // specify an adapter (see also next example)
        //  mAdapter = new MyAdapter(myDataset);
        // recyclerView.setAdapter(mAdapter);
        Cursor cursor = new RegDBHelper(this).selectalldata();
            dataholder=new ArrayList<>();
            String data = "";

        while (cursor.moveToNext()) {
            Model obj;
            obj = new Model("\n\n\n\n\n\n"+"userid: " + cursor.getString(0) + '\n' +
             "username: " + cursor.getString(1) + "\n" +
             "pwd: " + cursor.getString(2) + "\n" +
             "dob: " + cursor.getString(3) + "\n" +
            "email: " + cursor.getString(4) + "\n" +
            "createdon: " + cursor.getString(5) );
            dataholder.add(obj);
        }
        mAdapter = new MyAdapter(dataholder);
        recyclerView.setAdapter(mAdapter);

    }        // ...
}