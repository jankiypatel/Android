package com.example.loginreg;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
public final class  RegDBHelper extends SQLiteOpenHelper{

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
    public RegDBHelper(Context context) {
            super(context,db_struct.DB_NAME,null,1);
        }

        @Override

        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL("Create table if not exists "+ db_struct.DB_TABLE+" (_id INTEGER PRIMARY KEY AUTOINCREMENT,"+db_struct.COLUMN_NAME+" text NOT NULL unique, "+db_struct.COLUMN_PASSWORD+" text NOT NULL, "+db_struct.COLUMN_DOB+" Text NOT NULL,"+db_struct.COLUMN_EMAIL +" Text NOT NULL unique,"+db_struct.COLUMN_CREATEDON+" DATETIME DEFAULT CURRENT_TIMESTAMP)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("drop table if exists "+db_struct.DB_TABLE);
            onCreate(sqLiteDatabase);
        }

        public boolean insert(String table_name, String[] parameterName, String[] parameterValue){
            ContentValues cv=new ContentValues();

            for(int i=0;i<parameterName.length;i++){
                cv.put(parameterName[i], parameterValue[i]);
            }

            SQLiteDatabase db=this.getWritableDatabase();
            long result = db.insert(table_name,null,cv);
            if(result == -1) return false;
            else return true;
        }

        public boolean insertdata(String unm, String password, String dob, String email)
        {
            SQLiteDatabase db=this.getWritableDatabase();
            ContentValues cv=new ContentValues();
            cv.put(db_struct.COLUMN_NAME, unm);
            cv.put(db_struct.COLUMN_PASSWORD,password);
            cv.put(db_struct.COLUMN_DOB,dob);
            cv.put(db_struct.COLUMN_EMAIL,email);
            cv.put(db_struct.COLUMN_CREATEDON,getDateTime());
            long result = db.insert(db_struct.DB_TABLE,null,cv);
            if(result == -1) return false;
            else return true;
        }
    public Object getData(String uname, String pass)
    {
        Cursor c;
        try (SQLiteDatabase db = this.getWritableDatabase()) {
            String query=" select count(*) from "+db_struct.DB_TABLE+" where unm = '"+uname+"' and password= '"+pass+"'";
            Cursor cursor = db.rawQuery(query, null);
            cursor.moveToFirst();
            String count = cursor.getString(cursor.getColumnIndex(cursor.getColumnName(0)));
            return count;

        }
        }

    public Cursor selectalldata() {
        Cursor c2;
        SQLiteDatabase db = this.getWritableDatabase();
            c2 = db.rawQuery("SELECT * FROM "+ db_struct.DB_TABLE, null);
            return c2;
        //   Cursor c1 = dbHelper.selectalldata();

        }
    }



