package com.example.loginreg;

public class db_struct {
    public static final String DB_NAME = "users.db";
    public static final String DB_TABLE = "users";
    public static final int DB_VERSION = 1;
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "unm";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_CREATEDON = "created_on";
}
