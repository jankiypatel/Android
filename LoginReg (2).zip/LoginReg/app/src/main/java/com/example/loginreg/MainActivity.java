package com.example.loginreg;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    Button b2,b3;


    EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText)findViewById(R.id.uname);
        e2=(EditText)findViewById(R.id.password);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        final RegDBHelper dbHelper = new RegDBHelper(this);
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (e1.getText().toString().equals("admin") && e2.getText().toString().equals("admin@123")) {
                    Toast.makeText(getApplicationContext(), "Redirecting...", Toast.LENGTH_SHORT).show();
                    Intent n1 = new Intent(MainActivity.this, AdminHome.class);
                    startActivity(n1);

                } else if (e1.getText().toString().equalsIgnoreCase("") && e2.getText().toString().equalsIgnoreCase("")) {
                    builder.setTitle("Error");
                    builder.setMessage("Please enter all values");
                    builder.show();
                } else if (e1.getText().toString().equalsIgnoreCase("")) {
                    builder.setTitle("Error");
                    builder.setMessage("Please enter Username");
                    builder.show();
                } else if (e2.getText().toString().equalsIgnoreCase("")) {
                    builder.setTitle("Error");
                    builder.setMessage("Please enter Password");
                    builder.show();
                } else   {

                    switch (view.getId()) {
                        case (R.id.button2):
                            String username = e1.getText().toString();
                            String enteredPassword = e2.getText().toString();
                            //    String storedPassword = dbHelper.getData(enteredPassword);
                            int status = Integer.parseInt((String) dbHelper.getData(username, enteredPassword));
                            if (status > 0) {
                                builder.setMessage("Entered password and username is: " + enteredPassword + " ," + username + "\n");
                                // Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_LONG).show();
                                Intent n1 = new Intent(MainActivity.this, Home.class);
                                startActivity(n1);
                            } else {
                                builder.setMessage("Email and password do not match,Please try again!!!");
                                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Do nothing here because we override this button later to change the close behaviour.
                                        //However, we still need this because on older versions of Android unless we
                                        //pass a handler the button doesn't get instantiated
                                    }
                                });
                                final AlertDialog dialog = builder.create();
                                dialog.show();
//Overriding the handler immediately after show is probably a better approach than OnShowListener as described below
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Boolean wantToCloseDialog = true;
                                        //Do stuff, possibly set wantToCloseDialog to true then...
                                        if (wantToCloseDialog)
                                            dialog.dismiss();
                                        //else dialog stays open. Make sure you have an obvious way to close the dialog especially if you set cancellable to false.
                                    }
                                });
                                ///makeText(this, "Email and password don't match.", LENGTH_SHORT).show();
                            }
                            break;
                        default:
                            throw new IllegalStateException("Unexpected value: " + view.getId());
                    }
                }
            }

        });
        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent n1 = new Intent(MainActivity.this,Registration.class);
                startActivity(n1);
            }
        });
    }
}





