package com.example.loginreg;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static javax.xml.datatype.DatatypeConstants.DATETIME;
public class Registration extends AppCompatActivity {
    Button Register, selectall;
    EditText uname, email, password, Dob;


    final RegDBHelper dbHelper = new RegDBHelper(this);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        uname = (EditText) findViewById(R.id.uname);
        password = (EditText) findViewById(R.id.password);
        Dob = (EditText) findViewById(R.id.Dateofbirth);
        email = (EditText) findViewById(R.id.Email);
        Register = (Button) findViewById(R.id.Regist);
        selectall = (Button) findViewById(R.id.Selectall);
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);


        Register.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                if (uname.getText().toString().equals("admin") || password.getText().toString().equals("admin@123")) {
                    Toast.makeText(getApplicationContext(), "Admin couldn't register", Toast.LENGTH_SHORT).show();

                }
                else {

                    boolean isInserted = dbHelper.insert(db_struct.DB_TABLE,
                            new String[] {db_struct.COLUMN_NAME,db_struct.COLUMN_PASSWORD,db_struct.COLUMN_DOB,db_struct.COLUMN_EMAIL},
                            new String[] {uname.getText().toString(), password.getText().toString(), Dob.getText().toString(), email.getText().toString()}) ;

                    if(isInserted == true){
                        builder.setTitle("Success");
                        builder.setMessage("Registration done successfully!!");
                        builder.show();
                        Intent n1 = new Intent(Registration.this, MainActivity.class);
                        startActivity(n1);
                    }
                    else{
                        builder.setTitle("Error");
                        builder.setMessage("Username already exists");
                        builder.show();
                    }

//                    boolean b = dbHelper.insertdata(uname.getText().toString(), password.getText().toString(), Dob.getText().toString(), email.getText().toString());
//                    if (b) {
//                        builder.setTitle("Success");
//                        builder.setMessage("Registration done successfully!!");
//                        builder.show();
//                        Intent n1 = new Intent(Registration.this, MainActivity.class);
//                        startActivity(n1);
//                    } else {
//                        builder.setTitle("Error");
//                        builder.setMessage("Username already exists");
//                        builder.show();
//                    }
                }
            }


        });
        selectall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Cursor c = dbHelper.selectalldata();
                String data = "";
                while (c.moveToNext()) {
                    data += "username: " + c.getString(1) + "\n";
                    data += "uid: " + c.getString(0) + "\n";
                    data += "pwd: " + c.getString(2) + "\n";
                    data += "dob: " + c.getString(3) + "\n";
                    data += "email: " + c.getString(4) + "\n";
                    data += "createdon: " + c.getString(5) + "\n\n\n";

                }
                builder.setTitle("User Details");
                builder.setMessage(data);
                builder.show();
            }
        });

    }

}